#ifndef FORM1_H
#define FORM1_H
//#include "MainWindow.h"
#include <QWidget>
namespace Ui {
class Form1;//切换窗口2
}

class Form1 : public QWidget
{
    Q_OBJECT

public:
    explicit Form1(QWidget *parent = nullptr);
    ~Form1();

private slots:
    void on_pushButton_clicked();

signals:
    void reshow();//切换窗口3.0


private:
    Ui::Form1 *ui;


};

#endif // FORM1_H
