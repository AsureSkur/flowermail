#ifndef RECEIVING_H
#define RECEIVING_H
#include <QWidget>

namespace Ui {
class receiving;
}

class receiving : public QWidget
{
    Q_OBJECT

public:
    explicit receiving(QWidget *parent = nullptr);
    ~receiving();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_3_clicked();

signals:
    void reshow();

private:
    Ui::receiving *ui;
};

#endif // RECEIVING_H
