#ifndef BIN_H
#define BIN_H
#include <QWidget>

namespace Ui {
class bin;
}

class bin : public QWidget
{
    Q_OBJECT

public:
    explicit bin(QWidget *parent = nullptr);
    ~bin();

private slots:
    void on_pushButton_clicked();

signals:
    void reshow();

private:
    Ui::bin *ui;
};

#endif // BIN_H
