#include "receiving.h"
#include "ui_receiving.h"
#include "MainWindow.h"
#include"form1.h"
#include"bin.h"
#include"homepage.h"
#include"send_mail.h"
#include<QFile>
#include<QFileDialog>

receiving::receiving(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::receiving)
{
    ui->setupUi(this);
}

receiving::~receiving()
{
    delete ui;
}

void receiving::on_pushButton_clicked()
{
    emit reshow();//切换窗口2.0
    this->close();
}

void receiving::on_pushButton_3_clicked()
{

    QString path=QFileDialog::getOpenFileName(this,"open","../","");
        if(path.isEmpty()==false)
        {
            QFile file(path);
            bool OK=file.open(QIODevice::ReadOnly);
            if(OK==true)
            {
                QByteArray array=file.readAll();
                ui->textEdit->setText(array);

            }
            file.close();
        }

    /*QSqlQuery *sqlQuery = new QSqlQuery;
    QString sqlStr = "select id, name from info";
    sqlQuery->prepare( sqlStr );

    if( sqlQuery->exec() )
    {
       //读取查询到的记录
       while( sqlQuery->next() )
       {
           tableWidget->setItem( row, column, new QTableWidgetItem( sqlQuery->value(0).toString()));
           tableWidget->setItem( row, column, new QTableWidgetItem( sqkQuery->value(1).toString()))
       }
    }*/
}
