#include "ui_bin.h"
#include"bin.h"
bin::bin(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::bin)
{
    ui->setupUi(this);

}

bin::~bin()
{
    delete ui;
}

void bin::on_pushButton_clicked()
{
    emit reshow();//切换窗口2.0
    this->close();
}
