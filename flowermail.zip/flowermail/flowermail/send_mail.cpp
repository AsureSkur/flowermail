#include "send_mail.h"
#include "ui_send_mail.h"
#include "MainWindow.h"
#include"form1.h"
#include"bin.h"
#include"homepage.h"
#include"receiving.h"
send_mail::send_mail(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::send_mail)
{
    ui->setupUi(this);
}

send_mail::~send_mail()
{
    delete ui;
}

void send_mail::on_pushButton_2_clicked()
{
    emit reshow();//切换窗口2.0
    this->close();
}
