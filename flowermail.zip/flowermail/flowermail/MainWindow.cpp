#include "ui_MainWindow.h"
#include "MainWindow.h"
#include"form1.h"
#include"bin.h"
#include"homepage.h"
#include"receiving.h"
#include"send_mail.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(&regi,&Form1::reshow,[this]()//切换窗口1.0
                {
                    regi.close();
                    this->show();
                }
           );
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_clicked()
{
    this->hide();
    regi.show();//切换窗口3
}


void MainWindow::on_pushButton_2_clicked()
{
    this->hide();
    login.show();
}
