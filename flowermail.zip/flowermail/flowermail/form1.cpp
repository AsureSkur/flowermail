//#include "form1.h"
#include "ui_form1.h"
#include"MainWindow.h"
Form1::Form1(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Form1)
{
    ui->setupUi(this);
}

Form1::~Form1()
{
    delete ui;
}


void Form1::on_pushButton_clicked()
{
    emit reshow();//切换窗口2.0
    this->close();
}
