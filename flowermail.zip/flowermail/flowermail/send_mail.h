#ifndef SEND_MAIL_H
#define SEND_MAIL_H
#include <QWidget>

namespace Ui {
class send_mail;
}

class send_mail : public QWidget
{
    Q_OBJECT

public:
    explicit send_mail(QWidget *parent = nullptr);
    ~send_mail();

private slots:
    void on_pushButton_2_clicked();

signals:
    void reshow();

private:
    Ui::send_mail *ui;
};

#endif // SEND_MAIL_H
