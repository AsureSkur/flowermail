#include "homepage.h"
#include "ui_homepage.h"
#include "MainWindow.h"
#include"form1.h"
#include"bin.h"
#include"receiving.h"
#include"send_mail.h"
homepage::homepage(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::homepage)
{
    ui->setupUi(this);
    connect(&send,&send_mail::reshow,[this]()//切换窗口1.0
                {
                    send.close();
                    this->show();
                }
           );
    connect(&rece,&receiving::reshow,[this]()//切换窗口1.0
                {
                    rece.close();
                    this->show();
                }
           );
    connect(&bin,&bin::reshow,[this]()//切换窗口1.0
                {
                   bin.close();
                    this->show();
                }
           );
}

homepage::~homepage()
{
    delete ui;
}

void homepage::on_pushButton_clicked()
{
    this->hide();
    send.show();
}

void homepage::on_pushButton_2_clicked()
{
    this->hide();
    rece.show();
}

void homepage::on_pushButton_3_clicked()
{
    this->hide();
    bin.show();
}
