/********************************************************************************
** Form generated from reading UI file 'bin.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BIN_H
#define UI_BIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_bin
{
public:
    QLabel *label;
    QWidget *verticalLayoutWidget_2;
    QVBoxLayout *verticalLayout_2;
    QScrollBar *verticalScrollBar_2;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit;
    QPushButton *pushButton_3;
    QPushButton *pushButton;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QScrollBar *verticalScrollBar;
    QPushButton *pushButton_4;

    void setupUi(QWidget *bin)
    {
        if (bin->objectName().isEmpty())
            bin->setObjectName(QStringLiteral("bin"));
        bin->resize(400, 300);
        label = new QLabel(bin);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(90, -20, 261, 81));
        verticalLayoutWidget_2 = new QWidget(bin);
        verticalLayoutWidget_2->setObjectName(QStringLiteral("verticalLayoutWidget_2"));
        verticalLayoutWidget_2->setGeometry(QRect(190, 30, 191, 261));
        verticalLayout_2 = new QVBoxLayout(verticalLayoutWidget_2);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalScrollBar_2 = new QScrollBar(verticalLayoutWidget_2);
        verticalScrollBar_2->setObjectName(QStringLiteral("verticalScrollBar_2"));
        verticalScrollBar_2->setOrientation(Qt::Vertical);

        verticalLayout_2->addWidget(verticalScrollBar_2);

        pushButton_2 = new QPushButton(bin);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(90, 110, 93, 28));
        lineEdit = new QLineEdit(bin);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(100, 40, 81, 21));
        pushButton_3 = new QPushButton(bin);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(90, 70, 93, 28));
        pushButton = new QPushButton(bin);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(90, 190, 91, 28));
        verticalLayoutWidget = new QWidget(bin);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(0, 10, 81, 281));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalScrollBar = new QScrollBar(verticalLayoutWidget);
        verticalScrollBar->setObjectName(QStringLiteral("verticalScrollBar"));
        verticalScrollBar->setOrientation(Qt::Vertical);

        verticalLayout->addWidget(verticalScrollBar);

        pushButton_4 = new QPushButton(bin);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(90, 150, 93, 28));

        retranslateUi(bin);

        QMetaObject::connectSlotsByName(bin);
    } // setupUi

    void retranslateUi(QWidget *bin)
    {
        bin->setWindowTitle(QApplication::translate("bin", "Form", Q_NULLPTR));
        label->setText(QApplication::translate("bin", "\350\257\267\350\276\223\345\205\245\345\267\246\350\276\271\347\232\204\344\277\241\344\273\266\345\272\217\345\217\267\345\271\266\347\202\271\345\207\273\346\237\245\347\234\213", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("bin", "\345\275\273\345\272\225\345\210\240\351\231\244", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("bin", "\346\237\245\347\234\213", Q_NULLPTR));
        pushButton->setText(QApplication::translate("bin", "\350\277\224\345\233\236", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("bin", "\346\201\242\345\244\215", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class bin: public Ui_bin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BIN_H
