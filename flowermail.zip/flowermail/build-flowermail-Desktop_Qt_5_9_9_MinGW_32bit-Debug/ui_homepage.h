/********************************************************************************
** Form generated from reading UI file 'homepage.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOMEPAGE_H
#define UI_HOMEPAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_homepage
{
public:
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;

    void setupUi(QWidget *homepage)
    {
        if (homepage->objectName().isEmpty())
            homepage->setObjectName(QStringLiteral("homepage"));
        homepage->resize(194, 189);
        pushButton = new QPushButton(homepage);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(50, 30, 93, 28));
        pushButton_2 = new QPushButton(homepage);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 80, 93, 28));
        pushButton_3 = new QPushButton(homepage);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(50, 130, 93, 28));

        retranslateUi(homepage);

        QMetaObject::connectSlotsByName(homepage);
    } // setupUi

    void retranslateUi(QWidget *homepage)
    {
        homepage->setWindowTitle(QApplication::translate("homepage", "Form", Q_NULLPTR));
        pushButton->setText(QApplication::translate("homepage", "\345\206\231\344\277\241", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("homepage", "\346\224\266\344\277\241", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("homepage", "\345\236\203\345\234\276\347\256\261", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class homepage: public Ui_homepage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOMEPAGE_H
