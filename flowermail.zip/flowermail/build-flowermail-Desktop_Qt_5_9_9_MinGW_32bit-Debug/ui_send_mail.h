/********************************************************************************
** Form generated from reading UI file 'send_mail.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEND_MAIL_H
#define UI_SEND_MAIL_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_send_mail
{
public:
    QPushButton *pushButton;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QTextEdit *textEdit;
    QPushButton *pushButton_2;

    void setupUi(QWidget *send_mail)
    {
        if (send_mail->objectName().isEmpty())
            send_mail->setObjectName(QStringLiteral("send_mail"));
        send_mail->resize(400, 300);
        pushButton = new QPushButton(send_mail);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(130, 250, 93, 28));
        label = new QLabel(send_mail);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 30, 68, 15));
        label_2 = new QLabel(send_mail);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(60, 70, 68, 15));
        label_3 = new QLabel(send_mail);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(60, 110, 68, 15));
        lineEdit = new QLineEdit(send_mail);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(130, 30, 231, 21));
        lineEdit_2 = new QLineEdit(send_mail);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(130, 70, 231, 21));
        textEdit = new QTextEdit(send_mail);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(130, 110, 231, 121));
        pushButton_2 = new QPushButton(send_mail);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(270, 250, 93, 28));

        retranslateUi(send_mail);

        QMetaObject::connectSlotsByName(send_mail);
    } // setupUi

    void retranslateUi(QWidget *send_mail)
    {
        send_mail->setWindowTitle(QApplication::translate("send_mail", "Form", Q_NULLPTR));
        pushButton->setText(QApplication::translate("send_mail", "\345\217\221\351\200\201", Q_NULLPTR));
        label->setText(QApplication::translate("send_mail", "\346\224\266\344\273\266\344\272\272\357\274\232", Q_NULLPTR));
        label_2->setText(QApplication::translate("send_mail", "\344\270\273\351\242\230\357\274\232", Q_NULLPTR));
        label_3->setText(QApplication::translate("send_mail", "\346\255\243\346\226\207\357\274\232", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("send_mail", "\350\277\224\345\233\236", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class send_mail: public Ui_send_mail {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEND_MAIL_H
