/********************************************************************************
** Form generated from reading UI file 'form1.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FORM1_H
#define UI_FORM1_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Form1
{
public:
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_2;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QLabel *label;
    QPushButton *pushButton;
    QLineEdit *lineEdit;

    void setupUi(QWidget *Form1)
    {
        if (Form1->objectName().isEmpty())
            Form1->setObjectName(QStringLiteral("Form1"));
        Form1->resize(400, 300);
        label_3 = new QLabel(Form1);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(90, 140, 68, 15));
        label_4 = new QLabel(Form1);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(90, 180, 68, 15));
        lineEdit_3 = new QLineEdit(Form1);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(170, 180, 113, 21));
        pushButton_2 = new QPushButton(Form1);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(190, 220, 93, 28));
        label_2 = new QLabel(Form1);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(90, 110, 68, 15));
        lineEdit_2 = new QLineEdit(Form1);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(170, 140, 113, 21));
        label = new QLabel(Form1);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 20, 271, 81));
        pushButton = new QPushButton(Form1);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(50, 220, 121, 28));
        lineEdit = new QLineEdit(Form1);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(170, 110, 113, 21));
#ifndef QT_NO_SHORTCUT
        label_3->setBuddy(lineEdit_2);
        label_4->setBuddy(lineEdit_3);
        label_2->setBuddy(lineEdit);
#endif // QT_NO_SHORTCUT

        retranslateUi(Form1);

        QMetaObject::connectSlotsByName(Form1);
    } // setupUi

    void retranslateUi(QWidget *Form1)
    {
        Form1->setWindowTitle(QApplication::translate("Form1", "Form", Q_NULLPTR));
        label_3->setText(QApplication::translate("Form1", "\350\264\246\345\217\267\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        label_4->setText(QApplication::translate("Form1", "\347\241\256\350\256\244\345\257\206\347\240\201\357\274\232", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("Form1", "\347\241\256\350\256\244\346\263\250\345\206\214", Q_NULLPTR));
        label_2->setText(QApplication::translate("Form1", "\346\263\250\345\206\214\351\202\256\347\256\261\357\274\232", Q_NULLPTR));
        label->setText(QApplication::translate("Form1", "<html><head/><body><p><span style=\" font-size:28pt; font-weight:600; font-style:italic; color:#ff0000;\">\346\263\250\345\206\214\347\225\214\351\235\242</span></p></body></html>", Q_NULLPTR));
        pushButton->setText(QApplication::translate("Form1", "\350\277\224\345\233\236\347\231\273\345\275\225\351\241\265\351\235\242", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Form1: public Ui_Form1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORM1_H
