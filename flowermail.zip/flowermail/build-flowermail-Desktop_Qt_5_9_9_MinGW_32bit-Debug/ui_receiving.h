/********************************************************************************
** Form generated from reading UI file 'receiving.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RECEIVING_H
#define UI_RECEIVING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_receiving
{
public:
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QScrollBar *verticalScrollBar;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton;
    QLineEdit *lineEdit;
    QLabel *label;
    QTextEdit *textEdit;

    void setupUi(QWidget *receiving)
    {
        if (receiving->objectName().isEmpty())
            receiving->setObjectName(QStringLiteral("receiving"));
        receiving->resize(400, 300);
        verticalLayoutWidget = new QWidget(receiving);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(10, 10, 81, 281));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        verticalScrollBar = new QScrollBar(verticalLayoutWidget);
        verticalScrollBar->setObjectName(QStringLiteral("verticalScrollBar"));
        verticalScrollBar->setOrientation(Qt::Vertical);

        verticalLayout->addWidget(verticalScrollBar);

        pushButton_2 = new QPushButton(receiving);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(100, 110, 93, 28));
        pushButton_3 = new QPushButton(receiving);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(100, 70, 93, 28));
        pushButton = new QPushButton(receiving);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(100, 150, 91, 28));
        lineEdit = new QLineEdit(receiving);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(110, 40, 81, 21));
        label = new QLabel(receiving);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(100, 0, 261, 31));
        textEdit = new QTextEdit(receiving);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(220, 40, 171, 251));

        retranslateUi(receiving);

        QMetaObject::connectSlotsByName(receiving);
    } // setupUi

    void retranslateUi(QWidget *receiving)
    {
        receiving->setWindowTitle(QApplication::translate("receiving", "Form", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("receiving", "\345\210\240\351\231\244", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("receiving", "\346\237\245\347\234\213", Q_NULLPTR));
        pushButton->setText(QApplication::translate("receiving", "\350\277\224\345\233\236", Q_NULLPTR));
        label->setText(QApplication::translate("receiving", "\350\257\267\350\276\223\345\205\245\345\267\246\350\276\271\347\232\204\344\277\241\344\273\266\345\272\217\345\217\267\345\271\266\347\202\271\345\207\273\346\237\245\347\234\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class receiving: public Ui_receiving {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RECEIVING_H
